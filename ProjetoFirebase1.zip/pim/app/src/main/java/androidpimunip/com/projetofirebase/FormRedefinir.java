package androidpimunip.com.projetofirebase;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FormRedefinir extends AppCompatActivity {

    private  Button botao;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_redefinir);
        getSupportActionBar().hide();
        botao= (Button) findViewById(R.id.bt_redefinir);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Senha Redefinida com Sucesso",Toast.LENGTH_LONG).show();
            }
        });

    }
}