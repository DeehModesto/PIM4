package androidpimunip.com.projetofirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import android.view.View;

public class FormLogin extends AppCompatActivity {

    private TextView text_menu,txt_btn_esqueceu_a_senha;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_login);



        getSupportActionBar().hide();
        IniciarComponentes();
        IniciarComponentes1();

        txt_btn_esqueceu_a_senha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FormLogin.this,FormRedefinir.class);
                startActivity(intent);
            }
        });

        text_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(FormLogin.this,FormMenu.class);
                startActivity(intent);
            }

        });
    }

    private void IniciarComponentes () {text_menu = findViewById(R.id.bt_entrar);}
    private void IniciarComponentes1 () {txt_btn_esqueceu_a_senha = findViewById(R.id.bt_esquecer);}


}
